/*
Прошу вас написать приложение, которое хранит информацию о фильмах
и позволяет получaть все детали о них.
+реализовать поиск по части имени фильма

Основа: проектирование
в конце семинара объяснение
 */

import java.util.Scanner;

public class Programm {
    public static void main(String[] args) throws Exception{
        Scanner s = new Scanner(System.in);
        System.out.println("Choose mode.\n1.Find info about film\n2.Add new film\n3.View database");
        int mode = s.nextInt();
        s.close();
        if (mode == 1){
            Base.FindInfo();
        } else if (mode == 2) {
            GetFilmData.getFilmAL();
        } else if (mode == 3) {
            Base.PrintBase();

        }else {System.out.println("Error");}



    }

}
